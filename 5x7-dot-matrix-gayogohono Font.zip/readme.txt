﻿This font cloned “5x7 DOT Matrix” and added characters for the Gayogohó:nǫˀ Language (U+0118, U+0119, U+01EA, U+01EB, U+02C0, U+E000 - U+E00A, U+E014 - U+E01A, U+E024 - U+E02A, U+E034 - U+E03A). 

The text below corresponds to the “5x7 DOT Matrix” readme file. 


The font file in this archive was created using Fontstruct the free, online
font-building tool.
This font was created by “sylvan.black”*.
This font has a homepage where this archive and other versions may be found:
https://fontstruct.com/fontstructions/show/847768

*NOTE: “5x7 DOT Matrix” was originally cloned (copied) from the
FontStruction “LCD Dot Matrix HD44780U”
(https://fontstruct.com/fontstructions/show/476121) by Håvar Henriksen, which
is licensed under a Creative Commons Attribution Share Alike license
(http://creativecommons.org/licenses/by-sa/3.0/).
“LCD Dot Matrix HD44780U” was in turn cloned (copied) from the FontStruction
“5x8 LCD HD44780U A02” (https://fontstruct.com/fontstructions/show/310233)
by “vader381”, which is licensed under a Creative Commons Attribution Share
Alike license (http://creativecommons.org/licenses/by-sa/3.0/).
“5x8 LCD HD44780U A02” was in turn cloned (copied) from the FontStruction
“LCD Dot Matrix Condensed”
(https://fontstruct.com/fontstructions/show/150127) by Håvar Henriksen, which
is licensed under a Creative Commons Attribution Share Alike license
(http://creativecommons.org/licenses/by-sa/3.0/).
“LCD Dot Matrix Condensed” was in turn cloned (copied) from the
FontStruction “LCD Dot Matrix”
(https://fontstruct.com/fontstructions/show/142810) by Håvar Henriksen, which
is licensed under a Creative Commons Attribution Share Alike license
(http://creativecommons.org/licenses/by-sa/3.0/).

Try Fontstruct at https://fontstruct.com
It’s easy and it’s fun.

Fontstruct is copyright ©2013-2023 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.
